package com.ecommerce.repository;

import com.ecommerce.data.UserSignUp;
import com.ecommerce.exception.CustomerException;
import com.ecommerce.pojo.UserTable;

public interface UserRegisterDAO {
	public UserTable getUserByEmail(String email) throws CustomerException;
	public int addUser(UserSignUp newUser);
}
