package com.ecommerce.repository;

import org.springframework.stereotype.Repository;

import com.ecommerce.data.ForgotPassword;
import com.ecommerce.exception.CustomerException;
import com.ecommerce.exception.UserNotFoundException;
import com.ecommerce.pojo.UserTable;

@Repository
public interface UsersRepository {
	
	public int getUserByEmailAndPassword(String email, String password) throws UserNotFoundException;//saurav
	int updatePasswordFromMail(ForgotPassword reset) throws UserNotFoundException;//saurav
	
	public UserTable getUserById(int uId); //for testing
	
	public UserTable updateUser(long uId, UserTable user);
	
}