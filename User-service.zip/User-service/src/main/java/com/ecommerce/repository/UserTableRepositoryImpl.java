package com.ecommerce.repository;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ecommerce.data.ForgotPassword;
import com.ecommerce.exception.UserNotFoundException;
import com.ecommerce.pojo.UserTable;



@Repository
public class UserTableRepositoryImpl extends BaseRepository implements UsersRepository {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	@Transactional
	public int getUserByEmailAndPassword(String email, String password) throws UserNotFoundException{
		// TODO Auto-generated method stub
		Query q = null;
		try
		{
			String query = "select uId from UserTable where uEmail=:x and uPassword=:y";
			q = (Query) this.entityManager.createQuery(query);
			q.setParameter("x", email);
			q.setParameter("y", password);
			System.out.println("Result is :"+q.getSingleResult());
		}
		catch(Exception e)
		{
			throw new UserNotFoundException("user not found");
		}
		return (int)q.getSingleResult();
	}
	
	//Update password by mail
	@Transactional
	@Override
 public int updatePasswordFromMail(ForgotPassword reset) throws UserNotFoundException
 {
	
		EntityManager entityManager = getEntityManager();
		String uEmail=reset.getEmail();
		Query query = entityManager.createQuery("select  u from UserTable u where u.uEmail = :vjob");
		query.setParameter("vjob",uEmail);
	
		UserTable existingUser= (UserTable)query.getSingleResult();
	
		int uId = existingUser.getUId();
		UserTable existingUser1 = this.entityManager.find(UserTable.class, uId);
		existingUser1.setUPassword(reset.getPassword());
		this.entityManager.merge(existingUser1);
		return 100;
			}
	

	



	@Override
	public UserTable getUserById(int uId) {
		// TODO Auto-generated method stub
		UserTable user = this.entityManager.find(UserTable.class, uId);
		System.out.println("User is :"+user);
		return user;
	}

	@Override
	public UserTable updateUser(long uId, UserTable user) {
		// TODO Auto-generated method stub
		return null;
	}

}