package com.ecommerce.service;

import org.springframework.stereotype.Repository;

import com.ecommerce.data.Login;
import com.ecommerce.data.UserSignUp;
import com.ecommerce.exception.UserNotFoundException;
import com.ecommerce.pojo.UserTable;

@Repository
public interface UserService {

	public int login(Login login) throws UserNotFoundException;

	public int addUser(UserSignUp newUser);

	public UserTable getUserById(int uId);

}
