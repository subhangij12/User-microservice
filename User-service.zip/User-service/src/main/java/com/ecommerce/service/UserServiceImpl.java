package com.ecommerce.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ecommerce.data.Login;
import com.ecommerce.data.UserSignUp;
import com.ecommerce.exception.UserNotFoundException;
import com.ecommerce.pojo.UserTable;
import com.ecommerce.repository.UserRegisterDAO;
import com.ecommerce.repository.UserTableRepositoryImpl;


@Repository
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRegisterDAO userDAO;
	
	@Autowired
	UserTableRepositoryImpl UserRepoImpl;
	



	
	
	@Override
	public int login(Login login) throws UserNotFoundException{
		int id = this.UserRepoImpl.getUserByEmailAndPassword(login.getEmail(),login.getPassword());
		return id;
	}
	

	@Override
	public int addUser(UserSignUp newUser) {
		int id = 0;
		try
		{
			UserTable user = this.userDAO.getUserByEmail(newUser.getuEmail());
			return -1;
		}
		catch(NullPointerException e)
		{
			return -1;
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			id = this.userDAO.addUser(newUser);
		}
		return id;
	}


	@Override
	public UserTable getUserById(int uId) {
		// TODO Auto-generated method stub
		return this.UserRepoImpl.getUserById(uId);
	}
	
}
