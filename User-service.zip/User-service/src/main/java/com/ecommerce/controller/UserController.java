package com.ecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.data.Login;
import com.ecommerce.data.UserSignUp;
import com.ecommerce.exception.UserNotFoundException;
import com.ecommerce.pojo.UserTable;
import com.ecommerce.service.UserServiceImpl;



@CrossOrigin
@RestController
@RequestMapping("")
public class UserController {
	
	@Autowired
	UserServiceImpl UserServiceImpl;
	

	
//	http://localhost:8001/index
	
	@GetMapping(path = "/index") //passed
	public String home()
	{
		return "Welcome to EasyBuy ";
	}
//	---------------------------------------------------------------Fetch User details--------------------
//	http://localhost:8001/getUserById/301
	
	@GetMapping(path = "/getUserById/{uId}")
	public UserTable getUserById(@PathVariable String uId)
	{
		return this.UserServiceImpl.getUserById(Integer.parseInt(uId));
	}
	
//	--------------------------------------------------Add new user--------------------------------------
	

	@PostMapping(path = "/addNewUser")//passed but phone blank
	public int addNewUser(@RequestBody UserSignUp newUser)
	{
		return this.UserServiceImpl.addUser(newUser);
	}

//	-----------------------------------Login----------------------------------
//	Response Body
//	{
//
//	    "email": "scott@gmail.com",
//	   
//	    "password": "scm@0123"
//	    
//	}
//	returns user id (ex in this case 301)
//	http://localhost:8001/login
	
	@PostMapping(path = "/login")//passed 
	public int login(@RequestBody  Login login)
	{
		try {
			return this.UserServiceImpl.login(login);
		} catch (UserNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -100;
		}
	}

	
	

	
	
}

